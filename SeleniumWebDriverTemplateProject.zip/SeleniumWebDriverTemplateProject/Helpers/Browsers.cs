﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumWebDriverTemplateProject.Helpers
{
    public enum Browsers
    {
        //Don't forget to add the browser in the test setup method
        IE,Firefox,Android,Chrome,HtmlDriver,Opera,Safari,IPhone
    }
}
